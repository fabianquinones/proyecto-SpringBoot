package com.grupo3.EcoMarket;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Inventario {
    private Map<String, Producto> productos;
    private List<MovimientoInventario> historialMovimientos;
    
    // Constructor
    public Inventario() {
        this.productos = new HashMap<>();
        this.historialMovimientos = new ArrayList<>();
    }
    
    // Clase interna para representar productos
    public static class Producto {
        private String id;
        private String nombre;
        private String descripcion;
        private double precio;
        private int stock;
        private String categoria;
        private boolean esEcologico;
        private String proveedor;
        
        public Producto(String id, String nombre, String descripcion, double precio, int stock, 
                        String categoria, boolean esEcologico, String proveedor) {
            this.id = id;
            this.nombre = nombre;
            this.descripcion = descripcion;
            this.precio = precio;
            this.stock = stock;
            this.categoria = categoria;
            this.esEcologico = esEcologico;
            this.proveedor = proveedor;
        }
        
        // Getters y Setters
        public String getId() { return id; }
        public String getNombre() { return nombre; }
        public String getDescripcion() { return descripcion; }
        public double getPrecio() { return precio; }
        public int getStock() { return stock; }
        public String getCategoria() { return categoria; }
        public boolean isEsEcologico() { return esEcologico; }
        public String getProveedor() { return proveedor; }
        
        public void setNombre(String nombre) { this.nombre = nombre; }
        public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
        public void setPrecio(double precio) { this.precio = precio; }
        public void setStock(int stock) { this.stock = stock; }
        public void setCategoria(String categoria) { this.categoria = categoria; }
        public void setEsEcologico(boolean esEcologico) { this.esEcologico = esEcologico; }
        public void setProveedor(String proveedor) { this.proveedor = proveedor; }
    }
    
    // Clase interna para registrar movimientos de inventario
    public static class MovimientoInventario {
        private String idProducto;
        private String tipoMovimiento; // "ENTRADA", "SALIDA", "AJUSTE"
        private int cantidad;
        private String fecha;
        private String usuario;
        private String motivo;
        
        public MovimientoInventario(String idProducto, String tipoMovimiento, int cantidad, 
                                   String fecha, String usuario, String motivo) {
            this.idProducto = idProducto;
            this.tipoMovimiento = tipoMovimiento;
            this.cantidad = cantidad;
            this.fecha = fecha;
            this.usuario = usuario;
            this.motivo = motivo;
        }
        
        // Getters
        public String getIdProducto() { return idProducto; }
        public String getTipoMovimiento() { return tipoMovimiento; }
        public int getCantidad() { return cantidad; }
        public String getFecha() { return fecha; }
        public String getUsuario() { return usuario; }
        public String getMotivo() { return motivo; }
    }
    
    // Métodos para gestionar el inventario
    
    // Agregar un nuevo producto al inventario
    public boolean agregarProducto(Producto producto) {
        if (productos.containsKey(producto.getId())) {
            return false; // Producto ya existe
        }
        productos.put(producto.getId(), producto);
        registrarMovimiento(producto.getId(), "ENTRADA", producto.getStock(), 
                          "Nuevo producto agregado al inventario", "Sistema");
        return true;
    }
    
    // Actualizar información de un producto existente
    public boolean actualizarProducto(String id, Producto productoActualizado) {
        if (!productos.containsKey(id)) {
            return false; // Producto no encontrado
        }
        productos.put(id, productoActualizado);
        return true;
    }
    
    // Eliminar un producto del inventario
    public boolean eliminarProducto(String id) {
        if (!productos.containsKey(id)) {
            return false; // Producto no encontrado
        }
        productos.remove(id);
        return true;
    }
    
    // Ajustar el stock de un producto
    public boolean ajustarStock(String idProducto, int cantidad, String motivo, String usuario) {
        Producto producto = productos.get(idProducto);
        if (producto == null) {
            return false; // Producto no encontrado
        }
        
        int nuevoStock = producto.getStock() + cantidad;
        if (nuevoStock < 0) {
            return false; // Stock no puede ser negativo
        }
        
        producto.setStock(nuevoStock);
        String tipoMovimiento = cantidad > 0 ? "ENTRADA" : "SALIDA";
        registrarMovimiento(idProducto, tipoMovimiento, Math.abs(cantidad), motivo, usuario);
        return true;
    }
    
    // Consultar un producto por ID
    public Producto consultarProducto(String id) {
        return productos.get(id);
    }
    
    // Buscar productos por nombre o categoría
    public List<Producto> buscarProductos(String criterio) {
        List<Producto> resultados = new ArrayList<>();
        String criterioLower = criterio.toLowerCase();
        
        for (Producto producto : productos.values()) {
            if (producto.getNombre().toLowerCase().contains(criterioLower) ||
                producto.getCategoria().toLowerCase().contains(criterioLower)) {
                resultados.add(producto);
            }
        }
        return resultados;
    }
    
    // Verificar disponibilidad de stock
    public boolean verificarDisponibilidad(String idProducto, int cantidadRequerida) {
        Producto producto = productos.get(idProducto);
        return producto != null && producto.getStock() >= cantidadRequerida;
    }
    
    // Registrar un movimiento en el historial
    private void registrarMovimiento(String idProducto, String tipoMovimiento, int cantidad, 
                                   String motivo, String usuario) {
        String fecha = java.time.LocalDateTime.now().toString();
        MovimientoInventario movimiento = new MovimientoInventario(
            idProducto, tipoMovimiento, cantidad, fecha, usuario, motivo);
        historialMovimientos.add(movimiento);
    }
    
    // Generar reporte de inventario
    public String generarReporteInventario() {
        StringBuilder reporte = new StringBuilder();
        reporte.append("Reporte de Inventario - EcoMarket SPA\n");
        reporte.append("=====================================\n");
        reporte.append(String.format("%-10s %-30s %-10s %-10s %-15s\n", 
                      "ID", "Nombre", "Precio", "Stock", "Categoría"));
        
        for (Producto producto : productos.values()) {
            reporte.append(String.format("%-10s %-30s %-10.2f %-10d %-15s\n", 
                          producto.getId(), producto.getNombre(), 
                          producto.getPrecio(), producto.getStock(), 
                          producto.getCategoria()));
        }
        
        reporte.append("\nTotal de productos: ").append(productos.size());
        return reporte.toString();
    }
    
    // Obtener historial de movimientos para un producto
    public List<MovimientoInventario> obtenerHistorialProducto(String idProducto) {
        List<MovimientoInventario> historialProducto = new ArrayList<>();
        for (MovimientoInventario movimiento : historialMovimientos) {
            if (movimiento.getIdProducto().equals(idProducto)) {
                historialProducto.add(movimiento);
            }
        }
        return historialProducto;
    }
}