package com.grupo3.EcoMarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
